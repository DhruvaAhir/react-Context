import React from "react";
import { Routes, Route, Link, Navigate } from "react-router-dom";
import AddUser from "./pages/addUser";
import Profile from "./pages/profile";
import EditHistory from "./pages/editHistory";
import { AppBar, Box, Toolbar, Typography } from "@mui/material";

const AppRoutes = () => {
  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static">
          <Toolbar variant="dense">
            <Typography variant="h6" color="inherit" component="div">
              <Link style={{ textDecoration: "none", color: "white" }} to={"/"}>
                Home
              </Link>
            </Typography>
          </Toolbar>
        </AppBar>
      </Box>
      <Routes>
        <Route path="/" element={<Profile />} />
        <Route path="/add" element={<AddUser />} />
        <Route path="/history/:id" element={<EditHistory />} />
        <Route path="/*" element={<Navigate to={"/"} />} />
      </Routes>
    </>
  );
};
export default AppRoutes;
